import React from "react";
import { Link } from "react-router-dom";
import "../styles/App.css";
import SectionTitle from "./SectionTitle";

// Page d'Erreur section administration
const Error = () => {
    return (
        <div className="containerApp">
            <SectionTitle title="vous n'avez pas le droit d'accéder à cette page" />
            <Link to="/admin">Cliquez ici pour vous identifier</Link>
        </div>

    )
}
export default Error;