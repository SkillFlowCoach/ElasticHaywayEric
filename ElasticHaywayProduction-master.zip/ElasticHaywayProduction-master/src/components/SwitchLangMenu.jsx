import React, {useContext} from "react";
//import frenchFlag from "../assets/img/fr.svg";
//import englishFlag from "../assets/img/en.svg";
import "../styles/global.css";
import {Context} from "../context/langContext";

/**
 * Fonction qui détermine l'icone qui sera affiché
 * 
 * @returns Icone et Lien pour modifier la langue d'affichage
 */
const SwitchLangMenu = ()=>{
    const {toggleLang} = useContext(Context);
    const {lang} = useContext(Context);
    
    let invert = "en";
    // eslint-disable-next-line
    if ([lang] == "en") { invert = "fr" };
    
    return (
        <img src={"../img/"+[invert]+".svg"} alt={[invert]} onClick={()=>toggleLang([invert])}/>
    );
}

export default SwitchLangMenu;