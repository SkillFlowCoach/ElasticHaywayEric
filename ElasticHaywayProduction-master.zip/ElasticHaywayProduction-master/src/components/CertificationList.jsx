import React from "react";
import { Grid } from "semantic-ui-react";
import ProjectCard from "./ProjectCard";

function CertificationList(props) {
    return (
        <>
            {props.certifications.length === 0 ?
                (<div>Rien à afficher pour le moment</div>) :
                (
                    props.certifications.map((project, index) => (
                        <Grid.Column key={index}>
                            <ProjectCard data={project} />
                        </Grid.Column>
                    ))
                )
            }
        </>
    );
}

export default CertificationList;