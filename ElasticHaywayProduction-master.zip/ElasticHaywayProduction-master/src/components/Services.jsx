import Service from "./Service";
import services from "../data/services.json";
import Shape from "./Shape";

import {Context} from "../context/langContext";
import React, { useContext } from "react";

const Services = () => {
    const {lang} = useContext(Context);
    return (
        <section className="service-area relative pb-[100px] lg:pb-[200px]" id="services">
            <div className="container md:grid md:grid-cols-3 lg:gap-7">
                {services.map(service => (
                    <Service
                        key={service.id}
                        desc={service.desc[lang]}
                        title={service.title[lang]}
                        thumb={`/img/${service.icon}`}
                    />
                ))}
            </div>

            <Shape fillColor="#F9FAFB"/>
        </section>
    );
};

export default Services;
