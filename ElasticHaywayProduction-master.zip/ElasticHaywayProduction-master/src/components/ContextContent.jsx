import React, { useState, useEffect } from "react";

import ContextProvider from '../context/langContext';

import Preloader from "../components/Preloader";
import Header from "../components/Header";
import HeroArea from '../components/HeroArea';
import AboutMe from '../components/About';
import Publications from "../components/Publications";
import PortfolioPanel from '../components/PortfolioPanel';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

import axios from "axios";

const ContextContent =() => {

  // section connexion a mongo
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:4000/portfolio").then(response => {
      setData(response.data);
    }).catch(error => {
      console.log("Erreur : " + error);
    })
  }, []);
  
  //Effect preloader
  const [preloaded, setPreloaded] = useState(false);
  useEffect(() => {
    setTimeout(() => {
      setPreloaded(true);
    }, 800)
  }, []);

  return (
        <ContextProvider>
          <div className="rokstar">
            <Preloader preloaded={preloaded} />  
            <Header/>
            <HeroArea />
            <AboutMe />
            <Publications/>
            <PortfolioPanel data={{ data }} />
            <Contact />
            <Footer/>
          </div>
        </ContextProvider>
  );
}

export default ContextContent;
