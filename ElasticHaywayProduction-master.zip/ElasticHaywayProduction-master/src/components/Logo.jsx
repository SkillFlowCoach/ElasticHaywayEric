import Link from 'next/link';
import Image from "next/image";

const Logo = ({variant, className}) => {
    return (
        <Link>
            <a href="/" className={`leading-0 inline-block ${className ?? ""}`}>
                <Image
                    width={50}
                    height={50}
                    src={`/img/logo-${variant}.png`}
                     alt="logo"
                />
           </a>
        </Link> 
    );
};

Logo.defaultProps = {
    variant: "light"
}

export default Logo;
