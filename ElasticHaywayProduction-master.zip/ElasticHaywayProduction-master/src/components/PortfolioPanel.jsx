import React from "react";
import SectionTitle from "./SectionTitle";
import Shape from "./Shape";

// module projet, portfolio et certification
import ProjectList from "./ProjectList";
import PortfolioList from "./PortfolioList";
import CertificationList from "./CertificationList";

// utilisation de semantic ui
import { Tab } from "semantic-ui-react";
const styleLink = document.createElement("link");
styleLink.rel = "stylesheet";
styleLink.href = "https://cdn.jsdelivr.net/npm/semantic-ui/dist/semantic.min.css";
document.head.appendChild(styleLink);

const PortfolioPanel = function (props) {
  const globalCFG = [
    {
      menuItem: 'All',
      render: () =>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-7">
          <PortfolioList data={props.data} />
        </div>
    },
    {
      menuItem: "Projects",
      render: () =>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-7">
          <ProjectList projects={props.data.data.filter(item => item.category === "project")} />
        </div>
    },
    {
      menuItem: "Certifications",
      render: () =>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-7">
          <CertificationList certifications={props.data.data.filter(item => item.category === "certification")} />
        </div>
    },
  ];

  return (
    <section className="bg-gray-50 relative pt-[100px] pb-[100px] lg:pb-[200px]" id="portfolio">
      <div className="container">
        <SectionTitle title="Portfolios" />
          <Tab panes={globalCFG} />
      </div>
      <Shape />
    </section>
  )
}

export default PortfolioPanel;