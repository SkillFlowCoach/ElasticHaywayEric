import React from "react";
import "../styles/global.css";
import SectionTitle from "./SectionTitle";
import { Link } from "react-router-dom";

// 404 site principale
const NotFound = () => {
    return (
        <div className="container">
            <SectionTitle title="Il n'y a rien à voir ici" />

            <Link to="/">Cliquez ici pour retourner à la page d'accueil</Link>
        </div>
    )
}
export default NotFound;