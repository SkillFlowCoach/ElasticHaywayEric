import React from "react";
import { Grid } from "semantic-ui-react";
import ProjectCard from "./ProjectCard";

function ProjectList(props) {
    return (
        <>
            {props.projects.length === 0 ?
                (<div>Rien à afficher pour le moment</div>) :
                (props.projects.map((project, index) => (
                    <Grid.Column key={index}>
                        <ProjectCard data={project} />
                    </Grid.Column>
                ))
                )
            }
        </>
    );
}

export default ProjectList;