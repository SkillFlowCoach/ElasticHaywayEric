import Publication from "./Publication";
//import publications from "../data/publications.json";
import axios from 'axios';
import Shape from "./Shape";
import SectionTitle from "./SectionTitle";
import { useState, useEffect } from "react";
import icon from "../data/service-web-design.png";

const Publications = () => {
    //Téléchargement des données des publications depuis le back-end
    const [data, setData] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:4000/publication").then(response => {
            setData(response.data);
            console.log({ data });
        }).catch(error => {
            console.log("Erreur : " + error);
        })
    }, []);
    
    return (
        <section className="publication-area relative pb-[100px] lg:pb-[200px]" id="publications">
            <div className="container">
                <SectionTitle title="Publications" />
                <div className="container md:grid md:grid-cols-3 lg:gap-7">
                    {data.map((p, index) => (
                        <Publication
                            key={index}
                            url={p.url}
                            name={p.name}
                            thumb={`${icon}`}
                        />
                    ))}
                </div>

                <Shape fillColor="#F9FAFB" />
            </div>
        </section>
    );
};

export default Publications;
