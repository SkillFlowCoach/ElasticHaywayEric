import React, { useContext } from "react";
import { Card, Image } from 'semantic-ui-react';
import { Context } from "../context/langContext";

function ProjectCard({ data }) {
  const { lang } = useContext(Context);
  return (
    <>
      <div className={`relative duration-400 rounded-md overflow-hidden hover:drop-shadow-portfolio border-none ${bgOverlay}`} >
        <Card >
          <div className="ui segment">
            <div className="ui centered medium image">
              <Image src={data.thumb} wrapped ui={true} />

              <Card.Content>
                <Card.Header>{data.name[lang]}</Card.Header>
                <Card.Meta>
                  <span>{data.category}</span>
                </Card.Meta>
                <Card.Description>{data.description[lang]}</Card.Description>
              </Card.Content>
              <Card.Content extra></Card.Content>
            </div>
          </div>
        </Card>
      </div>
    </>
  );
}
const bgOverlay = "after:absolute after:bg-black after:inset-0 after:opacity-0 after:duration-400 hover:after:opacity-0";

export default ProjectCard;