/**
 * Section calqué sur "service"
 */
import PropTypes from "prop-types";

const Publication = ({ thumb, name, url, className }) => {
    return (
        <div className={`service group relative flex px-3 py-5 rounded-md duration-300 hover:bg-gray-50 ${publicationBefore} ${publicationAfter} ${className ?? ""}`}>
            {/* Publication Icon */}
            <div className="mr-4 bg-white group-hover:bg-gray-50 relative flex-shrink-0 self-start w-[50px] md:w-auto">
                <img
                    src={thumb}
                    alt={name}
                />
            </div>

            {/* Publication Content */}
            <div>
                <h2 className="font-semibold text-base mb-3">
                    <a href={url} target="_blank" rel="noopener noreferrer">{name}</a>
                </h2>

            </div>
        </div>
    );
};

const publicationBefore = "before:absolute before:left-10 before:top-9 before:h-[calc(100%-60px)] before:w-[1px] before:bg-gray-300";
const publicationAfter = "after:absolute after:left-9 after:bottom-4 after:h-[10px] after:w-[10px] after:rounded-full after:bg-gray-300 after:opacity-40";

Publication.propTypes = {
    thumb: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
}

export default Publication;
