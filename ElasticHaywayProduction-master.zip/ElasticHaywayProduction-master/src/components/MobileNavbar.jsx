import { useContext } from "react";
import {Link} from "react-scroll";
import navbar from "../data/navbar.json";

import "../styles/global.css";

//module pour la langue
import SwitchLangMenu from "./SwitchLangMenu";
import {Context} from "../context/langContext";

const MobileNavbar = ({className}) => {
    const {lang} = useContext(Context);
    return (
        <nav className={`bg-black w-44 rounded-md float-right overflow-hidden duration-300 sm:hidden ${className ?? ""}`}>
            <ul className="nav p-2">
                {navbar.map(item => (
                    <li key={item.id}>
                        <Link
                            spy={true}
                            smooth={true}
                            to={item.href}
                            data-hover={item.name[lang].toLowerCase()}
                            className={`block text-white rounded-md font-medium text-sm relative cursor-pointer py-1 px-3 duration-400 hover:bg-white hover:text-dark`}
                        >
                            {item.name[lang]}
                        </Link>
                    </li>
                ))}
                <li>
                    <Link 
                        spy={true}
                        smooth={true}
                        to={"#"}
                        className={`block text-white rounded-md font-medium text-sm relative cursor-pointer py-1 px-3 duration-400 hover:bg-white hover:text-dark `} >
                           <div className="container-langMob">
                                <SwitchLangMenu />
                            </div>
                    </Link>
                </li>
            </ul>
        </nav>
    );
};

export default MobileNavbar;
