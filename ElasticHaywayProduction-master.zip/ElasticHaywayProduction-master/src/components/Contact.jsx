import React, { useContext } from "react";
import {Context} from "../context/langContext";

import { IoMdArrowRoundForward } from "react-icons/io";

import ContactForm from "./ContactForm";
import SectionTitle from "./SectionTitle";
import ContactText from "../data/contact.json";

const Contact = () => {
    const {lang} = useContext(Context);
    return (
        
        <section className="py-[100px]" id="contact">
            <div className="container">
                <SectionTitle title="Contact" />
                    <div className="grid grid-cols-1 md:grid-cols-12">
                        <div className="col-span-2">            
                            <div className="font-medium  px-5 text-justify border-r-2">                     
                                {ContactText.formText[lang]}
                            </div>
                        </div>
                        <div className="col-span-1 py-6 px-1" style={{ color: "#c8ccd5" }}>
                            <IoMdArrowRoundForward/>
                        </div>
                        <div className="col-span-7 mt-10 md:mt-0">
                            <ContactForm/>
                        </div>
                    </div>
            </div>
        </section>
    );
};

export default Contact