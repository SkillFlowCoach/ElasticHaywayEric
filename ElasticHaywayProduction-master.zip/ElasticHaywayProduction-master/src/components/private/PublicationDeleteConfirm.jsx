import React from "react";
import "../../styles/App.css"
import { useNavigate } from "react-router-dom";
import { Form, Icon, Button, Label } from "semantic-ui-react";
import axios from "axios";


/*
* Cette fontion nettoie la session des données inutiles avant de retourner 
* à la page de la liste des publications/articles
*/
function cleanSession() {
    sessionStorage.removeItem("publicationId");
    sessionStorage.removeItem("publicationName");
}

function PublicationDeleteConfirm() {
    const publicationName = sessionStorage.getItem("publicationName");
    const navigate = useNavigate();
    const handleSubmit = (event) => {
        event.preventDefault();
        const publicationId = sessionStorage.getItem("publicationId");

        axios.delete(`http://localhost:4000/publication/${publicationId}`)
            .then((response) => {
                console.log(response.data);
                console.log(response.status);
                cleanSession();
                sessionStorage.setItem("publicationDeleted", response.data.message);
                navigate("/admin/dashboard/publication");
            }).catch((err) => {
                if (err.response) {
                    console.log(err.response.status);
                    console.log(err.response.data);
                }
            });
    }
    return (
        <div className="containerApp">
            <Form>
                <Form.Field>
                    <Label pointing='below'>Vous êtes sûr de vouloir supprimer l'élément intitulé <b>{publicationName}</b>?</Label>
                    <Button icon labelPosition='left'
                        onClick={() => {
                            cleanSession();
                            navigate('/admin/dashboard/publication');
                        }
                        } id="cancel">
                        <Icon name='arrow left' />Annuler
                    </Button>
                    <Button icon labelPosition='left' type='submit' negative
                        onClick={handleSubmit}>
                        <Icon name='trash alternate' />Confirmer la suppression
                    </Button>
                </Form.Field>
            </Form>
        </div >
    );
}
export default PublicationDeleteConfirm;