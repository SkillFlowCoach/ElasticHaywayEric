import React, { useState } from "react";
import "../../styles/App.css"
import { Form, Icon, Button, Input, Label } from "semantic-ui-react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import SectionTitle from "../SectionTitle";

function PublicationAdd() {

  const navigate = useNavigate();
  /*
  * States pour les différents messages d'erreur
  */
  const [errorName, setErrorName] = useState("");
  const [errorUrl, setErrorUrl] = useState("");
  const [errorForm, setErrorForm] = useState("");

  /*
  * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
  * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
  * met à jour son état avec le style display : block
  */
  const [errorNameDisplay, setErrorNameDisplay] = useState("none");
  const [errorUrlDisplay, setErrorUrlDisplay] = useState("none");
  const [errorFormDisplay, setErrorFormDisplay] = useState("none");

  /*
  * State pour les différents champs du formulaires
  */
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");

  const handleSubmit = (event) => {

    //Nettoyage et initialisation
    setName(name.trim());
    setUrl(url.trim());
    setErrorForm("");
    setErrorFormDisplay("none");
    event.preventDefault();

    //Gestion des messages à afficher en cas d'erreur
    if (name === "") {
      setErrorName("Le nom de l'article/publication est obligatoire");
    }
    if (url === "") {
      setErrorUrl("Le nom est obligatoire");
    }

    //Gestion de l'affichage des composants
    name === "" ? setErrorNameDisplay("block")
      : setErrorNameDisplay("none");
    url === "" ? setErrorUrlDisplay("block")
      : setErrorUrlDisplay("none");

    /*
    * Critères de validité du formulaire
    */
    const validForm = name !== "" && url !== "";
    if (validForm) {
      const publication = {
        name: name,
        url: url
      };
      axios.post("http://localhost:4000/publication", publication)
        .then((response) => {
          //console.log(response.data);
          //console.log(response.status);
          sessionStorage.setItem("publicationAdded", response.data.message);
          navigate("/admin/dashboard/publication");
        }).catch((err) => {
          if (err.response) {
            //console.log(err.response.status);
            //console.log(err.response.data);
            setErrorForm(err.response.data.message);
            setErrorFormDisplay("block");
          }
        });
    }
  }
  return (
    <div className="containerApp">
      <SectionTitle title="Ajout d'une nouvelle publication/article" />
      <Form>
        <Form.Field>
          <Label pointing='below'>Nom </Label>
          <Input placeholder='Nom de la publication/article' value={name}
            onChange={(event) => setName(event.target.value)}
            onFocus={() => setErrorNameDisplay("none")} />
          <Label pointing prompt style={{ display: errorNameDisplay }}>
            {errorName}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Lien</Label>
          <Input placeholder='Lien vers la publication/article' value={url}
            onChange={(event) => setUrl(event.target.value)}
            onFocus={() => setErrorUrlDisplay("none")} />
          <Label pointing prompt style={{ display: errorUrlDisplay }}>
            {errorUrl}
          </Label>
        </Form.Field>
        <Button primary icon labelPosition='left' type='submit' onClick={handleSubmit}>
          <Icon name="save" />
          Valider
        </Button>
        <Button icon labelPosition='left'
          onClick={() => navigate('/admin/dashboard/publication')} id="cancel">
          <Icon name='cancel' />Annuler
        </Button>
        <Form.Field>
          <Label id="errorForm" pointing prompt style={{ display: errorFormDisplay }}>
            {errorForm}
          </Label>
        </Form.Field>
      </Form>
    </div>
  );
}
export default PublicationAdd;