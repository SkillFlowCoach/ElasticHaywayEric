import React, { useState, useEffect } from "react";
import Error from "../Error";
import { useNavigate } from "react-router-dom";
import { Label, Container, Segment, Table, Button, Icon } from 'semantic-ui-react';
import "../../styles/App.css";
import "../../styles/global.css"
import axios from "axios";
import SectionTitle from "../SectionTitle";

/*
* Cette fonction sert à nettoyer la session des éléments ayant pour clés
* publicationAdded et publicationUpdated. Elle est appelée avant une navigation 
* pour que lors du retour vers le tableau de bord, les éventuels messages 
* d'ajout/modification d'une publication/article ne sont plus affichés.
*/
const cleanSession = () => {
    sessionStorage.removeItem("publicationAdded");
    sessionStorage.removeItem("publicationUpdated");
    sessionStorage.removeItem("publicationDeleted");
}
const storeInSession = (publication) => {
    sessionStorage.setItem("publicationId", publication._id);
    sessionStorage.setItem("publicationName", publication.name);
    sessionStorage.setItem("publicationUrl", publication.url)
}
const PublicationDashboard = () => {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:4000/publication").then(response => {
            setData(response.data);
            console.log({ data });
        }).catch(error => {
            console.log("Erreur : " + error);
        })
    }, []);

    if (sessionStorage.getItem("adminId")) {
        return (
            <div className="containerApp">
                <Segment clearing>
                    <div floated='right'>
                        <Button icon labelPosition='left' onClick={() => {
                            cleanSession();
                            navigate("/admin/dashboard/");
                        }
                        }>
                            <Icon name="arrow circle left" />Retour au tableau de bord
                        </Button>
                        <Button icon labelPosition='left' onClick={() => {
                            //On vide le contenu de la session
                            sessionStorage.clear();
                            navigate("/admin");
                        }
                        }>
                            <Icon name="log out" />Déconnexion
                        </Button>

                    </div>
                </Segment>
                <div>
                    <SectionTitle title="Liste des articles/publication" />

                    <Button icon labelPosition="left" onClick={
                        () => {
                            cleanSession();
                            navigate('/admin/dashboard/publication/add');
                        }
                    }>
                        <Icon name='plus' />Ajouter un article/une publication
                    </Button>
                    <Container fluid>
                        {
                            sessionStorage.getItem("publicationAdded") ?
                                <Label color="teal">
                                    {sessionStorage.getItem("publicationAdded")}
                                </Label>
                                : ""
                        }
                        {
                            sessionStorage.getItem("publicationUpdated") ?
                                <Label color="teal">
                                    {sessionStorage.getItem("publicationUpdated")}
                                </Label>
                                : ""
                        }
                        {
                            sessionStorage.getItem("publicationDeleted") ?
                                <Label color="teal">
                                    {sessionStorage.getItem("publicationDeleted")}
                                </Label>
                                : ""
                        }
                    </Container>
                    <Table>
                        <Table.Header>
                            <Table.Row>
                                <Table.HeaderCell>Nom</Table.HeaderCell>
                                <Table.HeaderCell>Lien</Table.HeaderCell>
                                <Table.HeaderCell style={{ textAlign: "center" }} colSpan='2'>Action</Table.HeaderCell>
                            </Table.Row>
                        </Table.Header>
                        <Table.Body>
                            {
                                data.map((publication, index) =>
                                    <Table.Row key={index}>
                                        <Table.Cell>{publication.name}</Table.Cell>
                                        <Table.Cell>
                                            <a href={publication.url} target="_blank" rel="noreferrer noopener">
                                                Ouvrir (lien externe)
                                            </a>
                                        </Table.Cell>
                                        <Table.Cell>
                                            <Button icon labelPosition='left' onClick={
                                                () => {
                                                    cleanSession();
                                                    //Sauvegarde des données de l'item dans la session
                                                    storeInSession(publication);
                                                    navigate('/admin/dashboard/publication/edit');
                                                }
                                            }>
                                                <Icon name='edit' />Modifier
                                            </Button></Table.Cell>
                                        <Table.Cell>
                                            <Button icon labelPosition='left' negative onClick={
                                                () => {
                                                    cleanSession();
                                                    sessionStorage.setItem("publicationId", publication._id);
                                                    sessionStorage.setItem("publicationName", publication.name);
                                                    navigate('/admin/dashboard/publication/delete');
                                                }
                                            } id="cancel">
                                                <Icon name='trash alternate' />Supprimer
                                            </Button>
                                        </Table.Cell>
                                    </Table.Row>
                                )}
                        </Table.Body>
                    </Table>
                </div>
            </div >

        );
    }
    return (
        <Error />
    )
}

export default PublicationDashboard;