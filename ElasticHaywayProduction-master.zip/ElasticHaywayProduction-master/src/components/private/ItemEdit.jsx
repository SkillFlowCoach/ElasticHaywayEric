import React, { useState } from "react";
import "../../styles/App.css"
import { useNavigate } from 'react-router-dom';
import { TextArea, Label, Input, Form, Select, Button, Icon } from "semantic-ui-react";
import axios from "axios";
import SectionTitle from "../SectionTitle";

const validateFileType = (filename) => {
    const ext = filename.split(".")[1];
    console.log(ext);
    return ext === "png" || ext === "jpg" || ext === "jpeg";
}

/*
* Cette fontion nettoie la session des données inutiles avant de retourner 
* à la page de la liste des publications/articles
*/
function cleanSession() {
    sessionStorage.removeItem("itemId");
    sessionStorage.removeItem("category");
    sessionStorage.removeItem("itemNameFr");
    sessionStorage.removeItem("itemNameEn");
    sessionStorage.removeItem("itemDescriptionFr");
    sessionStorage.removeItem("itemDescriptionEn");
    sessionStorage.removeItem("imageUrl")
}


const categories = [
    { key: "prj", value: "project", text: "Projet" },
    { key: "cer", value: "certification", text: "Certification" },
    { key: "art", value: "article", text: "Article scientifique" },
];


function ItemEdit() {

    //Récupération du contenu de la session    
    const item = {
        _id: sessionStorage.getItem("itemId"),
        category: sessionStorage.getItem("category"),
        name:
        {
            fr: sessionStorage.getItem("itemNameFr"),
            en: sessionStorage.getItem("itemNameEn")
        },
        description:
        {
            fr: sessionStorage.getItem("itemDescriptionFr"),
            en: sessionStorage.getItem("itemDescriptionEn")
        },
        thumb: sessionStorage.getItem("imageUrl")
    };
    const navigate = useNavigate();

    /*
    * State pour les différents messages d'erreur
    */
    const [errorCategory, setErrorCategory] = useState("");
    const [errorNameFr, setErrorNameFr] = useState("");
    const [errorNameEn, setErrorNameEn] = useState("");
    const [errorDescriptionFr, setErrorDescriptionFr] = useState("");
    const [errorDescriptionEn, setErrorDescriptionEn] = useState("");
    const [errorImage, setErrorImage] = useState("");
    const [errorForm, setErrorForm] = useState("");

    /*
   * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
   * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
   * met à jour son état avec le style display : block
   */
    const [errorCategoryDisplay, setErrorCategoryDisplay] = useState("none");
    const [errorNameFrDisplay, setErrorNameFrDisplay] = useState("none");
    const [errorNameEnDisplay, setErrorNameEnDisplay] = useState("none");
    const [errorDescriptionFrDisplay, setErrorDescriptionFrDisplay] = useState("none");
    const [errorDescriptionEnDisplay, setErrorDescriptionEnDisplay] = useState("none");
    const [errorImageDisplay, setErrorImageDisplay] = useState("none");
    const [errorFormDisplay, setErrorFormDisplay] = useState("none");

    /*
    * State pour les différents champs du formulaires
    */

    const [category, setCategory] = useState(item.category);
    const [nameFr, setNameFr] = useState(item.name.fr);
    const [nameEn, setNameEn] = useState(item.name.en);
    const [descriptionFr, setDescriptionFr] = useState(item.description.fr);
    const [descriptionEn, setDescriptionEn] = useState(item.description.en);


    const [selectedFile, setSelectedFile] = useState();
    /*
    * State de la modification de l'image : initialement, aucun fichier
    * n'a été chargé (false)
    */
    const [isSelectedFile, setIsSelectedFile] = useState(false);
    const handleFileSelection = (event) => {
        setIsSelectedFile(true);
        setSelectedFile(event.target.files[0]);
    };

    const handleSubmit = (event) => {
        //Nettoyage et initialisation
        setNameFr(nameFr.trim());
        setNameEn(nameEn.trim());
        setDescriptionFr(descriptionFr.trim());
        setDescriptionEn(descriptionEn.trim());
        setErrorForm("");
        setErrorFormDisplay("none");
        event.preventDefault();

        //Gestion des messages à afficher en cas d'erreur
        if (category !== "project" && category !== "certification") {
            setErrorCategory("Vous devez choisir une catégorie");
        }
        if (nameFr === "") {
            setErrorNameFr("Le nom est obligatoire");
        }
        if (nameEn === "") {
            setErrorNameEn("Le nom est obligatoire");
        }
        if (descriptionFr === "") {
            setErrorDescriptionFr("La description est obligatoire");
        }
        if (descriptionEn === "") {
            setErrorDescriptionEn("La description est obligatoire");
        }
        if (isSelectedFile && !validateFileType(selectedFile.name)) {
            setErrorImage("Seuls les fichiers .png, .jpg et .jpeg sont acceptés");
        }

        //Gestion de l'affichage des composants
        category !== "project" && category !== "certification" ?
            setErrorCategoryDisplay("block")
            : setErrorCategoryDisplay("none");
        nameFr === "" ? setErrorNameFrDisplay("block")
            : setErrorNameFrDisplay("none");
        nameEn === "" ? setErrorNameEnDisplay("block")
            : setErrorNameEnDisplay("none");
        descriptionFr === "" ? setErrorDescriptionFrDisplay("block")
            : setErrorDescriptionFrDisplay("none");
        descriptionEn === "" ? setErrorDescriptionEnDisplay("block")
            : setErrorDescriptionEnDisplay("none");
        isSelectedFile && !validateFileType(selectedFile.name) ? setErrorImageDisplay("block")
            : setErrorImageDisplay("none");

        /*
        * Critères de validité du formulaire : C'est à peu près la même chose que
        * pour le formulaire d'ajout, sauf qu'ici le fichier image est optionnel
        */
        const validForm = (category === "certification" || category === "project")
            && nameFr !== "" && nameEn !== ""
            && descriptionFr !== "" && descriptionEn !== "";
        console.log(validForm);
        if (validForm) {
            /*
            * Récupération des données à envoyer. Ici, il faut distinguer  le cas où l'image
            * à été chargé depuis l'ordinateur pour modification.
            * * En, le traitement est différent lors de l'upload d'un fichier
            * */
            item.category = category;
            item.name.fr = nameFr;
            item.name.en = nameEn;
            item.description.fr = descriptionFr;
            item.description.en = descriptionEn;
            if (isSelectedFile) {
                if (validateFileType(selectedFile.name)) {
                    console.log("fichier sélectionné");
                    //console.log("FIchier : ");
                    //console.log(selectedFile);
                    const config = { headers: { 'Content-Type': 'multipart/form-data' } };
                    const formData = new FormData();
                    formData.append("file", selectedFile);
                    formData.append("item", JSON.stringify(item));
                    //Requête AJAX avec envoi de fichier vers l'API
                    axios.put(`http://localhost:4000/portfolio/${item._id}`, formData, config)
                        .then((response) => {
                            console.log("Rspon uploa");
                            console.log(response.data);
                            console.log(response.status);
                            cleanSession();
                            sessionStorage.setItem("itemUpdated", response.data.message);
                            navigate("/admin/dashboard");
                        }).catch((err) => {
                            if (err.response) {
                                console.log("catch uploa");
                                setErrorForm(err.response.data.message);
                                setErrorFormDisplay("block");
                                console.log(err.response.status);
                                console.log(err.response.data);
                            }
                        });
                }

            } else {
                console.log("Données à envoyer : ");
                console.log(item);
                //Requête AJAX sans envoi de fichier vers L'API
                axios.put(`http://localhost:4000/portfolio/${item._id}`, item)
                    .then((response) => {
                        console.log("dans the")
                        console.log(response.data);
                        console.log(response.status);
                        cleanSession();
                        sessionStorage.setItem("itemUpdated", response.data.message);
                        navigate("/admin/dashboard");
                    }).catch((err) => {
                        if (err.response) {
                            console.log("Das catch");
                            console.log(err.response.data);

                            setErrorForm(err.response.data.message);
                            setErrorFormDisplay("block");
                        }
                    });
            }
        }
    }
    return (
        <div className="containerApp">
            <SectionTitle title="Mise à jour de la sélection" />
            <Form>
                <Form.Field>
                    <Label pointing='below'>Catégorie</Label>
                    <Select placeholder='Catégorie' options={categories} name="category"
                        value={category} onChange={(event, { value }) => setCategory(value)}
                        onFocus={() => setErrorCategoryDisplay("none")} />
                    <Label pointing prompt style={{ display: errorCategoryDisplay }}>
                        {errorCategory}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Nom</Label>
                    <Input placeholder='Nom' value={nameFr}
                        onChange={(event) => setNameFr(event.target.value)}
                        onFocus={() => setErrorNameFrDisplay("none")} />
                    <Label pointing prompt style={{ display: errorNameFrDisplay }}>
                        {errorNameFr}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Name</Label>
                    <Input placeholder='Name (english)' value={nameEn}
                        onChange={(event) => setNameEn(event.target.value)}
                        onFocus={() => setErrorNameEnDisplay("none")} />
                    <Label pointing prompt style={{ display: errorNameEnDisplay }}>
                        {errorNameEn}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Description</Label>
                    <TextArea placeholder='Description' value={descriptionFr}
                        onChange={(event) => setDescriptionFr(event.target.value)}
                        onFocus={() => setErrorDescriptionFrDisplay("none")} />
                    <Label pointing prompt style={{ display: errorDescriptionFrDisplay }}>
                        {errorDescriptionFr}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Description</Label>
                    <TextArea placeholder='Description (english)' value={descriptionEn}
                        onChange={(event) => setDescriptionEn(event.target.value)}
                        onFocus={() => setErrorDescriptionEnDisplay("none")} />
                    <Label pointing prompt style={{ display: errorDescriptionEnDisplay }}>
                        {errorDescriptionEn}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label>URL de l'image </Label>
                    <Input value={item.thumb} />
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>
                        Charger un fichier image depuis votre ordinateur pour mettre à jour l'URL de l'image
                        <br />
                        Types acceptés : uniquement .png, .jpg et .jpeg
                    </Label>
                    <Input type="file" onChange={handleFileSelection}
                        onFocus={() => setErrorImageDisplay("none")} />
                    <Label pointing prompt style={{ display: errorImageDisplay }}>
                        {errorImage}
                    </Label>
                </Form.Field>
                <Button primary icon labelPosition='left' type='submit' onClick={handleSubmit}>
                    <Icon name='edit' />
                    Mettre à jour
                </Button>
                <Button icon labelPosition='left'
                    onClick={() => {
                        cleanSession();
                        navigate('/admin/dashboard');
                    }
                    } id="cancel">
                    <Icon name='cancel' />Annuler
                </Button>
                <Form.Field>
                    <Label id="errorForm" pointing prompt style={{ display: errorFormDisplay }}>
                        {errorForm}
                    </Label>
                </Form.Field>
            </Form>
        </div>
    );

}
export default ItemEdit;