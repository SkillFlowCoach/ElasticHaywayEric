import React, { useState, useEffect } from "react";
import "../../styles/App.css"
import { useNavigate } from 'react-router-dom';
import { Label, Input, Form, Button, Icon } from "semantic-ui-react";
import axios from "axios";
import { AUT_TOKEN_KEY } from '../../App';
import SectionTitle from "../SectionTitle";

function PasswordReset() {

  const navigate = useNavigate();

  /*
  * State pour les différents messages d'erreur
  */
  const [errorLogin, setErrorLogin] = useState("");
  const [errorFirstAnswer, setErrorFirstAnswer] = useState("");
  const [errorSecondAnswer, setErrorSecondAnswer] = useState("");
  const [errorNewPwd, setErrorNewPwd] = useState("");
  const [errorNewPwdConfirm, setErrorNewPwdConfirm] = useState("");
  const [errorForm, setErrorForm] = useState("");

  /*
  * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
  * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
  * met à jour son état avec le style display : block
  */
  const [errorLoginDisplay, setErrorCurrentPwdDisplay] = useState("none");
  const [errorFirstAnswerDisplay, setErrorFirstAnswerDisplay] = useState("none");
  const [errorSecondAnswerDisplay, setErrorSecondAnswerDisplay] = useState("none");
  const [errorNewPwdDisplay, setErrorNewPwdDisplay] = useState("none");
  const [errorNewPwdConfirmDisplay, setErrorNewPwdConfirmDisplay] = useState("none");
  const [errorFormDisplay, setErrorFormDisplay] = useState("none");

  /*
   *Le composant doit d'abord télécharger les données des questions de sécurité 
   */
  useEffect(() => {

    //Requête pour récupérer les questions de sécurité du compte de l'admin
    axios.get("http://localhost:4000/auth/reset")
      .then(response => {
        setQuestionData(response.data.data);
      }).catch(error => {
        console.log("Erreur : " + error);
      })
  }, []);

  const [questionData, setQuestionData] = useState({});
  const [currentPwd, setCurrentPwd] = useState("");
  const [firstAnswer, setFirstAnswer] = useState("");
  const [secondAnswer, setSecondAnswer] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [newPwdConfirm, setNewPwdConfirm] = useState("");


  const handleSubmit = (event) => {

    //Nettoyage et initialisation
    setCurrentPwd(currentPwd.trim());
    setNewPwd(newPwd.trim());
    setNewPwdConfirm(newPwdConfirm.trim());
    setFirstAnswer(firstAnswer.trim());
    setSecondAnswer(secondAnswer.trim());
    setErrorForm("");
    setErrorFormDisplay("none");
    event.preventDefault();

    //Gestion des messages à afficher en cas d'erreur
    if (currentPwd === "") {
      setErrorLogin("Le login est obligatoire");
    }
    if (firstAnswer === "") {
      setErrorFirstAnswer("Champ obligatoire");
      return;
    }

    if (secondAnswer === "") {
      setErrorSecondAnswer("Champ obligatoire");
      return;
    }

    if (newPwd.length < 8) {
      setErrorNewPwd("Le nouveau mot de passe doit être avoir une longueur minimale" +
        " de 8 caractères");
    }

    if (newPwdConfirm.length < 8) {
      setErrorNewPwdConfirm("Le confirmation du  mot de passe doit être avoir une longueur" +
        " minimale de 8 caractères");
    }

    //Gestion de l'affichage des composants d'erreur
    currentPwd === "" ? setErrorCurrentPwdDisplay("block")
      : setErrorCurrentPwdDisplay("none");
    firstAnswer === "" ? setErrorFirstAnswerDisplay("block")
      : setErrorFirstAnswerDisplay("none");
    firstAnswer === "" ? setErrorFirstAnswerDisplay("block")
      : setErrorFirstAnswerDisplay("none");
    secondAnswer === "" ? setErrorSecondAnswerDisplay("block")
      : setErrorSecondAnswerDisplay("none");
    newPwd.length < 8 ? setErrorNewPwdDisplay("block")
      : setErrorNewPwdDisplay("none");
    newPwdConfirm.length < 8 ? setErrorNewPwdConfirmDisplay("block")
      : setErrorNewPwdConfirmDisplay("none");

    if (newPwd !== newPwdConfirm) {
      setErrorForm("Le mot de passe et sa confirmation ne sont pas identiques");
      setErrorFormDisplay("block");
    }

    /*
    * Critères de validité du formulaire
    */
    const validForm = currentPwd !== "" && newPwd.length >= 8 && newPwdConfirm.length >= 8
      && newPwd === newPwdConfirm && firstAnswer !== "" && secondAnswer !== "";
    console.log(validForm);
    if (validForm) {
      const data = {
        login: currentPwd,
        firstAnswer: firstAnswer,
        secondAnswer: secondAnswer,
        newPwd: newPwd
      };
      //Appel axios
      axios.put("http://localhost:4000/password/reset", data)
        .then((response) => {
          console.log(response.data);
          console.log(response.status);
          sessionStorage.setItem("pwdInitialized", response.data.pwdInitialized);
          sessionStorage.setItem("adminId", response.data.adminId);
          sessionStorage.setItem("name", response.data.name);
          sessionStorage.setItem(AUT_TOKEN_KEY, response.data.token);
          sessionStorage.setItem("message", response.data.message);
          navigate("/admin/dashboard");
        }).catch((err) => {
          if (err.response) {
            console.log(err.response.status);
            console.log(err.response.data);
            setErrorForm(err.response.data.message);
            setErrorFormDisplay("block");
          }
        });
    }
  }
  return (
    <div className="containerApp">
      <SectionTitle title="Réinitialisation du mot de passe" />
      <Form>
        <Form.Field>
          <Label pointing='below'>Login</Label>
          <Input placeholder='Login' value={currentPwd}
            onChange={(event) => setCurrentPwd(event.target.value)} id="login"
            onFocus={() => setErrorCurrentPwdDisplay("none")} />
          <Label pointing prompt style={{ display: errorLoginDisplay }}>
            {errorLogin}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Première question de sécurité : {questionData.firstQuestion}</Label>
          <Input placeholder='Réponse à la première question' value={firstAnswer}
            onChange={(event) => setFirstAnswer(event.target.value)} id="q1"
            onFocus={() => setErrorFirstAnswerDisplay("none")} />
          <Label pointing prompt style={{ display: errorFirstAnswerDisplay }}>
            {errorFirstAnswer}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Seconde question de sécurité : {questionData.secondQuestion}</Label>
          <Input placeholder='Réponse à la seconde question' value={secondAnswer}
            onChange={(event) => setSecondAnswer(event.target.value)} id="q2"
            onFocus={() => setErrorSecondAnswerDisplay("none")} />
          <Label pointing prompt style={{ display: errorSecondAnswerDisplay }}>
            {errorSecondAnswer}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Nouveau mot de passe (minimum 8 caractères)</Label>
          <input type="password" placeholder='Nouveau mot de passe' value={newPwd}
            onChange={(event) => setNewPwd(event.target.value)} id="password"
            onFocus={() => setErrorNewPwdDisplay("none")} />
          <Label pointing prompt style={{ display: errorNewPwdDisplay }}>
            {errorNewPwd}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Confirmation du mot de passe (minimum 8 caractères)</Label>
          <input type="password" placeholder='Confirmation du mot de passe' value={newPwdConfirm}
            onChange={(event) => setNewPwdConfirm(event.target.value)} id="password"
            onFocus={() => setErrorNewPwdConfirmDisplay("none")} />
          <Label pointing prompt style={{ display: errorNewPwdConfirmDisplay }}>
            {errorNewPwdConfirm}
          </Label>
        </Form.Field>

        <Button primary icon labelPosition='left' type='submit' onClick={handleSubmit}>
          <Icon name='edit' />
          Réinitialiser
        </Button>
        <Button icon labelPosition='left'
          onClick={() => navigate('/admin')} id="cancel">
          <Icon name='cancel' />Annuler
        </Button>
        <Form.Field>
          <Label id="errorForm" pointing prompt style={{ display: errorFormDisplay }}>
            {errorForm}
          </Label>
        </Form.Field>
      </Form>
    </div>
  );

}
export default PasswordReset;