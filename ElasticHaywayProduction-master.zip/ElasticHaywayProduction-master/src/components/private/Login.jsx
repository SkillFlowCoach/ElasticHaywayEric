import axios from 'axios';
import { Link } from "react-router-dom";
import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import Dashboard from './Dashboard';
import { Button, Form, Icon, Label } from 'semantic-ui-react';
import "../../styles/App.css"
import { AUT_TOKEN_KEY } from '../../App';
import SectionTitle from "../SectionTitle";

const Login = () => {
  //let pwdInitialized = false;
  /* Les hooks ne doivent pas être appelés dans une condition : toujours
  * les appeler au début du composant, même s'il ne seront utilisé que 
  * dans des alternatives
   */
  const [login, setLogin] = useState(localStorage.getItem("login"));
  const navigate = useNavigate();
  const [password, setPassword] = useState(localStorage.getItem("password"));
  /*
  * L'objet localStorage ne peut contenir que des chaines de caractères. D'où 
  * l'expression localStorage.getItem("stayConnected") === "true", qui renvoie
  * un résultat de type boolean
  */
  const [stayConnected, setStayConnected] = useState(localStorage.getItem("stayConnected") === "true");
  //States pour la validation du formulaire
  const [errorLogin, setErrorLogin] = useState("");
  const [errorPassword, setErrorPassword] = useState("");
  const [errorForm, setErrorForm] = useState("");

  /*
  * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
  * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
  * met à jour son état avec le style display : block
  */
  const [errorLoginDisplay, setErrorLoginDisplay] = useState("none");
  const [errorPasswordDisplay, setErrorPasswordDisplay] = useState("none");
  const [errorFormDisplay, setErrorFormDisplay] = useState("none");

  /*
  * Si l'admin s'est déjà connecté au site, la route /admin le redirigera vers 
  * automatiquement vers le tableau de bord 
  */

  if (sessionStorage.getItem("adminId")) {
    return (
      <Dashboard />
    )
  }

  const sendData = (event) => {

    event.preventDefault();
    /*
     * Lors de chaque soumission, il faut effacer l'éventuel message d'erreur de la 
     * soumission précédente, et cacher le composant correspondant
     */
    setErrorForm("");
    setErrorFormDisplay("none");
    setLogin(login.trim());
    setPassword(password.trim());

    //Gestion des messages à afficher en cas d'erreur
    if (login === "") {
      setErrorLogin("Le login est obligatoire");
    }
    if (password === "") {
      setErrorPassword("Le mot de passe est obligatoire");
    }
    //Gestion de l'affichage des composants
    login === "" ? setErrorLoginDisplay("block") : setErrorLoginDisplay("none");
    password === "" ? setErrorPasswordDisplay("block") : setErrorPasswordDisplay("none");

    /*
    * L'envoi du formulaire ne peut se faire que si le login et le mot de passe
    * ont été renseignés (Les states login et password ne sont pas vide)
    */
    const validForm = login !== "" && password !== "";
    if (validForm) {
      axios.post("http://localhost:4000/auth/login", {
        login: login,
        pwd: password
      })
        .then((response) => {
          //console.log("OK");
          //console.log(response.data.pwdInitialized);
          sessionStorage.setItem("pwdInitialized", response.data.pwdInitialized);
          sessionStorage.setItem("adminId", response.data.adminId);
          sessionStorage.setItem("name", response.data.name);
          sessionStorage.setItem(AUT_TOKEN_KEY, response.data.token);
          /*
          * Si l'option Rester connecté est activée, on sauvagarde le mot de passe dans 
          * le localStorage. Le formulaire de login est alors initialisé avec le contenu
          * de cet objet. Si l'utilisateur désactive cette option, on vide simplement le
          * localStorage et un login/mot de passe doivent alors être fournis
          * 
          * NB : on sauvegarde aussi le choix de l'utilisateur afin de mettre à jour le 
          * localStorage en cas de modification du mot de passe et que l'option Rester connecté
          * est activée
          * 
          */

          if (stayConnected) {
            localStorage.setItem("login", login);
            localStorage.setItem("password", password);
            localStorage.setItem("stayConnected", true);
          } else {
            localStorage.setItem("login", "");
            localStorage.setItem("password", "");
            localStorage.setItem("stayConnected", false);
          }
          localStorage.setItem("stayConnected", stayConnected);
          navigate("/admin/dashboard");
        }).catch((err) => {
          if (err.response) {
            setErrorForm(err.response.data.message);
            setErrorFormDisplay("block");
          }
        });
    }
  }
  return (
    <div className="containerApp">
      <SectionTitle title="Connexion" />
      <Form>
        <Form.Field>
          <Label pointing='below'>Identifiant</Label>
          <input name="login" placeholder='Identifiant' required value={login}
            onChange={(event) => setLogin((event.target.value))}
            onFocus={() => setErrorLoginDisplay("none")}
            id="login" />
          <Label pointing prompt style={{ display: errorLoginDisplay }}>
            {errorLogin}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Mot de passe</Label>
          <input type='password' name="pwd" value={password} required
            onFocus={() => setErrorPasswordDisplay("none")}
            onChange={(event) => setPassword(event.target.value)} id="password" />
          <Label pointing prompt style={{ display: errorPasswordDisplay }}>
            {errorPassword}
          </Label>
        </Form.Field>
        <Form.Field inline>
          <input type="checkbox" id="checkbox" checked={stayConnected}
            onChange={() => setStayConnected(!stayConnected)} />
          <Label pointing='left' htmlFor="checkbox">Rester connecté (non recommandé sur un ordinateur partagé)</Label>
        </Form.Field>
        <div>
          <br />
          <Button primary type='submit' onClick={sendData} icon labelPosition='left' >
            <Icon name="sign in" />Se connecter
          </Button>
        </div>
        <Form.Field>
          <Label pointing prompt style={{ display: errorFormDisplay }}>
            {errorForm}
          </Label>
        </Form.Field>
      </Form>

      <div>
        <br />
        Mot de passe oublié? <Link to="/admin/passInit">Cliquez ici</Link>
      </div>
    </div>
  );
}

export default Login