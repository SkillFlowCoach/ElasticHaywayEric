import React from "react";
import { Form, Button, Icon, Card, Image } from 'semantic-ui-react';
import { useNavigate } from 'react-router-dom';
import "../../styles/App.css"
import SectionTitle from "../SectionTitle";

/*
* Cette fontion nettoie la session des données inutiles avant de retourner 
* à la page de la liste des publications/articles
*/
function cleanSession() {
    sessionStorage.removeItem("itemId");
    sessionStorage.removeItem("category");
    sessionStorage.removeItem("itemNameFr");
    sessionStorage.removeItem("itemNameEn");
    sessionStorage.removeItem("itemDescriptionFr");
    sessionStorage.removeItem("itemDescriptionEn");
    sessionStorage.removeItem("imageUrl")
}

function ItemDetails() {

    const navigate = useNavigate();
    //Récupération du contenu de la session    
    const item = {
        "_id": sessionStorage.getItem("itemId"),
        "category": sessionStorage.getItem("categorye"),
        "name":
        {
            "fr": sessionStorage.getItem("itemNameFr"),
            "en": sessionStorage.getItem("itemNameEn")
        },
        "description":
        {
            "fr": sessionStorage.getItem("itemDescriptionFr"),
            "en": sessionStorage.getItem("itemDescriptionEn")
        },
        "thumb": sessionStorage.getItem("imageUrl")
    };
    return (
        <div className="containerApp">
            <SectionTitle title="Détails de la sélection" />
            <Card>
                <Image src={item.thumb} wrapped ui={false} />
                <Card.Content>
                    <Card.Header>{item.name.fr}</Card.Header>
                    <Card.Meta>
                        <span>{item.category}</span>
                    </Card.Meta>
                    <Card.Description>{item.description.fr}</Card.Description>
                </Card.Content>
                <Card.Content extra></Card.Content>
            </Card>
            <Form>
                <Form.Field>
                    <Button icon labelPosition='left'
                        onClick={() => {
                            cleanSession();
                            navigate('/admin/dashboard');
                        }}>
                        <Icon name='arrow left' />Retour au tableau de bord
                    </Button>
                </Form.Field>
            </Form>
        </div>
    );

}
export default ItemDetails;