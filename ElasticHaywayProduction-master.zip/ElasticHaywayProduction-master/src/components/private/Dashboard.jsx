import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Dropdown, Menu, Segment, Table, Button, Icon, Label } from 'semantic-ui-react';

import "../../styles/App.css"

import axios from "axios";
import PasswordInit from "./PasswordInit";
import SectionTitle from "../SectionTitle";
import Error from "../Error";

/*
* Cette fonction sert à nettoyer la session des éléments ayant pour clés
* "confirmationUpdatePwd", "message", itemAdded et itemUpdated. Elle est 
* appelée avant une navigation pour que lors du retour vers le tableau de bord, 
* les éventuels messages de réinitialisation/modification du mot de passe et
* d'ajout/modification d'un item ne sont plus affichés.
*/
const cleanSession = () => {
    sessionStorage.removeItem("confirmationUpdatePwd");
    sessionStorage.removeItem("message");
    sessionStorage.removeItem("confirmationInitPwd");
    sessionStorage.removeItem("itemAdded");
    sessionStorage.removeItem("itemUpdated");
    sessionStorage.removeItem("itemDeleted");
}
const storeInSession = (item) => {
    sessionStorage.setItem("itemId", item._id);
    sessionStorage.setItem("category", item.category);
    sessionStorage.setItem("itemNameFr", item.name.fr);
    sessionStorage.setItem("itemNameEn", item.name.en);
    sessionStorage.setItem("itemDescriptionFr", item.description.fr);
    sessionStorage.setItem("itemDescriptionEn", item.description.en);
    sessionStorage.setItem("imageUrl", item.thumb);
}
const Dashboard = () => {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:4000/portfolio")
            .then(response => {
                setData(response.data);
                console.log({ data });
            }).catch(error => {
                console.log("Erreur : " + error);
            })
    }, []);
    if (sessionStorage.getItem("adminId")) {
        /*
        * On force l'administrateur à modifier son mot de passe s'il s'agit de sa première
        * connexion.
        */
        if (sessionStorage.getItem("pwdInitialized") === "false") {
            return (
                <PasswordInit />
            );
        }
        return (
            <div className="containerApp">
                <SectionTitle title="Compte" />
                {
                    sessionStorage.getItem("confirmationUpdatePwd") ?
                        <Label color="teal">
                            {sessionStorage.getItem("confirmationUpdatePwd")}
                        </Label>
                        : ""
                }
                {
                    sessionStorage.getItem("message") ?
                        <Label color="teal">
                            {sessionStorage.getItem("message")}
                        </Label>
                        : ""
                }
                {
                    sessionStorage.getItem("confirmationInitPwd") ?
                        <Label color="teal">
                            {sessionStorage.getItem("confirmationInitPwd")}
                        </Label>
                        : ""
                }
                {
                    sessionStorage.getItem("itemAdded") ?
                        <Label color="teal">
                            {sessionStorage.getItem("itemAdded")}
                        </Label>
                        : ""
                }
                {
                    sessionStorage.getItem("itemUpdated") ?
                        <Label color="teal">
                            {sessionStorage.getItem("itemUpdated")}
                        </Label>
                        : ""
                }
                {
                    sessionStorage.getItem("itemDeleted") ?
                        <Label color="teal">
                            {sessionStorage.getItem("itemDeleted")}
                        </Label>
                        : ""
                }


                <Segment.Group horizontal>
                    <Segment>
                        Bienvenu, {sessionStorage.getItem("name")}
                    </Segment>
                    <Segment>
                        <Menu.Item>
                            <Dropdown style={{ backgroundColor: "#BBB", borderRadius: 2, padding: 5 }} item text='Mon compte'>
                                <Dropdown.Menu>
                                    <Dropdown.Item>
                                        <Button icon labelPosition='left' onClick={() => {
                                            cleanSession();
                                            navigate("/admin/dashboard/passEdit");
                                        }
                                        }>
                                            <Icon name="setting" />Modifier le mot de passe
                                        </Button>
                                    </Dropdown.Item>
                                    <Dropdown.Item>
                                        <Button icon labelPosition='left' onClick={() => {
                                            //On vide le contenu de la session
                                            sessionStorage.clear();
                                            navigate("/admin");
                                        }
                                        }>
                                            <Icon name="log out" />Déconnexion
                                        </Button>
                                    </Dropdown.Item>
                                </Dropdown.Menu>
                            </Dropdown>
                        </Menu.Item>
                    </Segment>
                </Segment.Group>
                <div>
                    <SectionTitle title="Tableau de bord" />
                    <Button icon labelPosition="left" onClick={
                        () => {
                            cleanSession();
                            navigate('/admin/dashboard/itemAdd');
                        }
                    }>
                        <Icon name='plus' />Ajouter un projet/une certification
                    </Button>
                    <Button onClick={
                        () => {
                            cleanSession();
                            navigate('/admin/dashboard/publication');
                        }
                    }>
                        Gestion des publications
                    </Button>
                    <Table singleLine>
                        <Table.Header>
                            <Table.Row>
                                <Table.HeaderCell>Nom</Table.HeaderCell>
                                <Table.HeaderCell>Type</Table.HeaderCell>
                                <Table.HeaderCell style={{ textAlign: "center" }} colSpan='3'>Action</Table.HeaderCell>
                            </Table.Row>
                        </Table.Header>
                        <Table.Body>
                            {
                                data.map((item, index) =>
                                    <Table.Row key={index}>
                                        <Table.Cell>{item.name.fr}</Table.Cell>
                                        <Table.Cell>{item.category}</Table.Cell>
                                        <Table.Cell>
                                            <Button icon labelPosition='left' onClick={
                                                () => {
                                                    cleanSession();
                                                    storeInSession(item);
                                                    navigate('/admin/dashboard/itemDetails');
                                                }
                                            }>
                                                <Icon name='eye' />Voir
                                            </Button>
                                        </Table.Cell>
                                        <Table.Cell>
                                            <Button icon labelPosition='left' onClick={
                                                () => {
                                                    cleanSession();
                                                    //Sauvegarde des données de l'item dans la session
                                                    storeInSession(item);
                                                    navigate('/admin/dashboard/itemEdit');
                                                }
                                            }>
                                                <Icon name='edit' />Modifier
                                            </Button></Table.Cell>
                                        <Table.Cell>
                                            <Button icon labelPosition='left' negative onClick={
                                                () => {
                                                    cleanSession();
                                                    sessionStorage.setItem("itemId", item._id);
                                                    sessionStorage.setItem("itemName", item.name.fr);
                                                    navigate('/admin/dashboard/itemDelete');
                                                }
                                            } id="cancel">
                                                <Icon name='trash alternate' />Supprimer
                                            </Button>
                                        </Table.Cell>
                                    </Table.Row>
                                )}
                        </Table.Body>
                    </Table>
                </div>
            </div >

        );
    }
    return (
        <Error />
    )
}

export default Dashboard;