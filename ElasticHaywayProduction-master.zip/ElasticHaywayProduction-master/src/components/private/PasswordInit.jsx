import React, { useState } from "react";
import "../../styles/App.css"
import { useNavigate } from 'react-router-dom';
import { Select, Label, Form, Button, Icon } from "semantic-ui-react";
import axios from "axios";
import SectionTitle from "../SectionTitle";


//tableaux de données pour les <Select> représentant les questions secrètes
const firtQuestionData = [
  { key: "pmtwn", value: "town", text: "Dans quelle ville se sont rencontrés vos parents?" },
  { key: "fproj", value: "project", text: "Qu’est-ce vous vouliez devenir plus grand, lorsque vous étiez enfant?" }
];
const secondQuestionData = [
  { key: "teach", value: "teacher", text: "Quel est le nom de famille de votre professeur d’enfance préféré?" },
  { key: "carb", value: "carbrand", text: "Quelle est la marque de votre première voiture?" }
];

function PasswordInit() {

  const navigate = useNavigate();

  /*
  * State pour les différents messages d'erreur
  */
  const [errorCurrendPwd, setErrorCurrentPwd] = useState("");
  const [errorFirstQuestion, setErrorFirstQuestion] = useState("");
  const [errorSecondQuestion, setErrorSecondQuestion] = useState("");
  const [errorFirstAnswer, setErrorFirstAnswer] = useState("");
  const [errorSecondAnswer, setErrorSecondAnswer] = useState("");
  const [errorNewPwd, setErrorNewPwd] = useState("");
  const [errorNewPwdConfirm, setErrorNewPwdConfirm] = useState("");
  const [errorForm, setErrorForm] = useState("");

  /*
  * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
  * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
  * met à jour son état avec le style display : block
  */
  const [errorCurrentPwdDisplay, setErrorCurrentPwdDisplay] = useState("none");
  const [errorFirstQuestionDisplay, setErrorFirstQuestionDisplay] = useState("none");
  const [errorSecondQuestionDisplay, setErrorSecondQuestionDisplay] = useState("none");
  const [errorFirstAnswerDisplay, setErrorFirstAnswerDisplay] = useState("none");
  const [errorSecondAnswerDisplay, setErrorSecondAnswerDisplay] = useState("none");
  const [errorNewPwdDisplay, setErrorNewPwdDisplay] = useState("none");
  const [errorNewPwdConfirmDisplay, setErrorNewPwdConfirmDisplay] = useState("none");
  const [errorFormDisplay, setErrorFormDisplay] = useState("none");

  /*
  * State pour les différents champs du formulaires
  */
  const [currentPwd, setCurrentPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [newPwdConfirm, setNewPwdConfirm] = useState("");
  const [firstQuestion, setFirstQuestion] = useState("");
  const [firstAnswer, setFirstAnswer] = useState("");
  const [secondQuestion, setSecondQuestion] = useState("");
  const [secondAnswer, setSecondAnswer] = useState("");

  const handleSubmit = (event) => {

    //Nettoyage et initialisation
    setCurrentPwd(currentPwd.trim());
    setNewPwd(newPwd.trim());
    setNewPwdConfirm(newPwdConfirm.trim());
    setFirstAnswer(firstAnswer.trim());
    setSecondAnswer(secondAnswer.trim());
    setErrorForm("");
    setErrorFormDisplay("none");
    event.preventDefault();

    //Gestion des messages à afficher en cas d'erreur
    if (currentPwd === "") {
      setErrorCurrentPwd("Le mot de passe actuel est obligatoire");
    }

    if (newPwd.length < 8) {
      setErrorNewPwd("Le nouveau mot de passe doit être avoir une longueur minimale" +
        " de 8 caractères");
    }

    if (newPwdConfirm.length < 8) {
      setErrorNewPwdConfirm("Le confirmation du  mot de passe doit être avoir une longueur" +
        " minimale de 8 caractères");
    }

    if (firstQuestion !== "town" && firstQuestion !== "project") {
      setErrorFirstQuestion("Vous devez choisir une première question");
    }

    if (secondQuestion !== "teacher" && secondQuestion !== "carbrand") {
      setErrorSecondQuestion("Vous devez choisir une seconde question");
    }

    if (firstAnswer === "") {
      setErrorFirstAnswer("La réponse à la première question est obligatoire");
    }

    if (secondAnswer === "") {
      setErrorSecondAnswer("La réponse à la seconde question est obligatoire");
    }

    //Gestion de l'affichage des composants d'erreur
    currentPwd === "" ? setErrorCurrentPwdDisplay("block")
      : setErrorCurrentPwdDisplay("none");
    firstAnswer === "" ? setErrorFirstAnswerDisplay("block")
      : setErrorFirstAnswerDisplay("none");
    secondAnswer === "" ? setErrorSecondAnswerDisplay("block")
      : setErrorSecondAnswerDisplay("none");
    firstQuestion !== "town" && firstQuestion !== "project" ?
      setErrorFirstQuestionDisplay("block")
      : setErrorFirstQuestionDisplay("none");
    secondQuestion !== "teacher" && secondQuestion !== "carbrand"
      ? setErrorSecondQuestionDisplay("block")
      : setErrorSecondQuestionDisplay("none");
    newPwd.length < 8 ? setErrorNewPwdDisplay("block")
      : setErrorNewPwdDisplay("none");
    newPwdConfirm.length < 8 ? setErrorNewPwdConfirmDisplay("block")
      : setErrorNewPwdConfirmDisplay("none");

    if (newPwd !== newPwdConfirm) {
      setErrorForm("Le mot de passe et sa confirmation ne sont pas identiques");
      setErrorFormDisplay("block");
    }

    /*
    * Critères de validité du formulaire
    */
    const validForm = currentPwd !== "" && newPwd.length >= 8 && newPwdConfirm.length >= 8
      && (firstQuestion === "town" || firstQuestion === "project")
      && (secondQuestion === "teacher" || secondQuestion === "carbrand")
      && newPwd === newPwdConfirm && firstAnswer !== "" && secondAnswer !== "";

    if (validForm) {
      const data = {
        currentPwd: currentPwd,
        newPwd: newPwd,
        firstQuestion: firstQuestion,
        firstAnswer: firstAnswer,
        secondQuestion: secondQuestion,
        secondAnswer: secondAnswer,
        firstLogin: true
      };
      axios.put("http://localhost:4000/password/edit", data)
        .then((response) => {
          console.log(response.data);
          console.log(response.status);
          /*
          * On met à jour le mot de passe si l'utilisateur a activé l'option 
          * Rester connecté
          */
          const stayConnected = localStorage.getItem("stayConnected") === "true";
          if (stayConnected) {
            localStorage.setItem("password", newPwd);
          }

          //On Sauvegarde le message de confirmation dans la session
          console.log(response.data.message);
          //sessionStorage.setItem("confirmationUpdatePwd", response.data.message);
          sessionStorage.setItem("confirmationInitPwd", response.data.message);
          /*
          * On sauvegarde dans la session l'état de la modification du mot de passe. 
          * Cette information (true/false) provient du back-end et indique (si false)
          * que le mot de passe dans la collection Admin est le mot de passe par défaut.
          * Cela permettra au composant Dashboard de forcer l'administrateur à modifier
          * son mot de passe par défaut car il s'agit de sa première connexion.
          */
          sessionStorage.setItem("pwdInitialized", response.data.pwdInitialized);
          navigate("/admin/dashboard");
        }).catch((err) => {
          if (err.response) {
            console.log(err.response.status);
            console.log(err.response.data);
            setErrorForm(err.response.data.message);
            setErrorFormDisplay("block");
          }
        });
    }

    //console.log(data);

  }
  return (
    <div className="containerApp">
      <SectionTitle title="Vous devez modifier votre mot de passe par défaut" />
      <Form>
        <Form.Field>
          <Label pointing='below'>Mot de passe actuel</Label>
          <input type="password" placeholder='Votre mot de passe actuel' value={currentPwd}
            onChange={(event) => setCurrentPwd(event.target.value)} id="password"
            onFocus={() => setErrorCurrentPwdDisplay("none")} />
          <Label pointing prompt style={{ display: errorCurrentPwdDisplay }}>
            {errorCurrendPwd}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Nouveau mot de passe (minimum 8 caractères)</Label>
          <input type="password" placeholder='Votre nouveau mot de passe' value={newPwd}
            onChange={(event) => setNewPwd(event.target.value)} id="password"
            onFocus={() => setErrorNewPwdDisplay("none")} />
          <Label pointing prompt style={{ display: errorNewPwdDisplay }}>
            {errorNewPwd}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Confirmation du mot de passe (minimum 8 caractères)</Label>
          <input type="password" placeholder='Confirmation du nouveau mot de passe' value={newPwdConfirm}
            onChange={(event) => setNewPwdConfirm(event.target.value)} id="passwordConfirm"
            onFocus={() => setErrorNewPwdConfirmDisplay("none")} />
          <Label pointing prompt style={{ display: errorNewPwdConfirmDisplay }}>
            {errorNewPwdConfirm}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Choisissez votre première question secrète</Label>
          <Select placeholder='Première question ' options={firtQuestionData}
            name="firstQuestion" value={firstQuestion} id="q1"
            onChange={(event, { value }) => setFirstQuestion(value)}
            onFocus={() => setErrorFirstQuestionDisplay("none")} />
          <Label pointing prompt style={{ display: errorFirstQuestionDisplay }}>
            {errorFirstQuestion}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Réponse à la première question</Label>
          <input type="text" placeholder='Votre réponse' value={firstAnswer}
            onChange={(event) => setFirstAnswer(event.target.value)} id="q1Answer"
            onFocus={() => setErrorFirstAnswerDisplay("none")} />
          <Label pointing prompt style={{ display: errorFirstAnswerDisplay }}>
            {errorFirstAnswer}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Choisissez votre seconde question secrète</Label>
          <Select placeholder='Seconde question' options={secondQuestionData}
            name="secondQuestion" value={secondQuestion} id="q2"
            onChange={(event, { value }) => setSecondQuestion(value)}
            onFocus={() => setErrorSecondQuestionDisplay("none")} />
          <Label pointing prompt style={{ display: errorSecondQuestionDisplay }}>
            {errorSecondQuestion}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Réponse à la seconde question</Label>
          <input type="text" placeholder='Votre réponse' value={secondAnswer} id="q2Answer"
            onChange={(event) => setSecondAnswer(event.target.value)}
            onFocus={() => setErrorSecondAnswerDisplay("none")} />
          <Label pointing prompt style={{ display: errorSecondAnswerDisplay }}>
            {errorSecondAnswer}
          </Label>
        </Form.Field>
        <Button primary icon labelPosition='left' type='submit' onClick={handleSubmit}>
          <Icon name='edit' />
          Modifier
        </Button>
        <Form.Field>
          <Label id="errorForm" pointing prompt style={{ display: errorFormDisplay }}>
            {errorForm}
          </Label>
        </Form.Field>
      </Form>
    </div>
  );
}
export default PasswordInit;