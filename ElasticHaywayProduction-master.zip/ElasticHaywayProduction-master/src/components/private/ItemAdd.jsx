import React, { useState } from "react";
import "../../styles/App.css"
import { Form, Select, Icon, Button, Input, TextArea, Label } from "semantic-ui-react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import SectionTitle from "../SectionTitle";

const validateFileType = (filename) => {
    const ext = filename.split(".")[1];
    console.log(ext);
    return ext === "png" || ext === "jpg" || ext === "jpeg";
}

const categories = [
    { key: "prj", value: "project", text: "Projet" },
    { key: "cer", value: "certification", text: "Certification" },
];
function ItemAdd() {
    const navigate = useNavigate();

    /*
    * State pour les différents messages d'erreur
    */
    const [errorCategory, setErrorCategory] = useState("");
    const [errorNameFr, setErrorNameFr] = useState("");
    const [errorNameEn, setErrorNameEn] = useState("");
    const [errorDescriptionFr, setErrorDescriptionFr] = useState("");
    const [errorDescriptionEn, setErrorDescriptionEn] = useState("");
    const [errorImage, setErrorImage] = useState("");
    const [errorForm, setErrorForm] = useState("");

    /*
    * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
    * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
    * met à jour son état avec le style display : block
    */
    const [errorCategoryDisplay, setErrorCategoryDisplay] = useState("none");
    const [errorNameFrDisplay, setErrorNameFrDisplay] = useState("none");
    const [errorNameEnDisplay, setErrorNameEnDisplay] = useState("none");
    const [errorDescriptionFrDisplay, setErrorDescriptionFrDisplay] = useState("none");
    const [errorDescriptionEnDisplay, setErrorDescriptionEnDisplay] = useState("none");
    const [errorImageDisplay, setErrorImageDisplay] = useState("none");
    const [errorFormDisplay, setErrorFormDisplay] = useState("none");

    /*
    * State pour les différents champs du formulaires
    */
    const [category, setCategory] = useState("");
    const [nameFr, setNameFr] = useState("");
    const [nameEn, setNameEn] = useState("");
    const [descriptionFr, setDescriptionFr] = useState("");
    const [descriptionEn, setDescriptionEn] = useState("");
    const [selectedFile, setSelectedFile] = useState();
    const [isSelectedFile, setIsSelectedFile] = useState(false);

    const handleFileSelection = (event) => {
        setSelectedFile(event.target.files[0]);
        setIsSelectedFile(true);
    };

    const handleSubmit = (event) => {
        //Nettoyage et initialisation
        setNameFr(nameFr.trim());
        setNameEn(nameEn.trim());
        setDescriptionFr(descriptionFr.trim());
        setDescriptionEn(descriptionEn.trim());
        setErrorForm("");
        setErrorFormDisplay("none");
        event.preventDefault();

        //Gestion des messages à afficher en cas d'erreur
        if (category !== "project" && category !== "certification") {
            setErrorCategory("Vous devez choisir une catégorie");
        }
        if (nameFr === "") {
            setErrorNameFr("Le nom est obligatoire");
        }
        if (nameEn === "") {
            setErrorNameEn("Le nom est obligatoire");
        }
        if (descriptionFr === "") {
            setErrorDescriptionFr("La description est obligatoire");
        }
        if (descriptionEn === "") {
            setErrorDescriptionEn("La description est obligatoire");
        }
        if (!isSelectedFile) {
            setErrorImage("L'image est obligatoire");
        } else if (!validateFileType(selectedFile.name)) {
            setErrorImage("Seuls les fichiers .png, .jpg et .jpeg sont acceptés");
        }

        //Gestion de l'affichage des composants
        category !== "project" && category !== "certification" ?
            setErrorCategoryDisplay("block")
            : setErrorCategoryDisplay("none");
        nameFr === "" ? setErrorNameFrDisplay("block")
            : setErrorNameFrDisplay("none");
        nameEn === "" ? setErrorNameEnDisplay("block")
            : setErrorNameEnDisplay("none");
        descriptionFr === "" ? setErrorDescriptionFrDisplay("block")
            : setErrorDescriptionFrDisplay("none");
        descriptionEn === "" ? setErrorDescriptionEnDisplay("block")
            : setErrorDescriptionEnDisplay("none");
        !isSelectedFile || !validateFileType(selectedFile.name) ? setErrorImageDisplay("block")
            : setErrorImageDisplay("none");

        /*
        * Critères de validité du formulaire
        */
        const validForm = (category === "certification" || category === "project")
            && nameFr !== "" && nameEn !== ""
            && descriptionFr !== "" && descriptionEn !== ""
            && isSelectedFile && validateFileType(selectedFile.name);
        //console.log(selectedFile);
        //console.log(validateFileType(selectedFile.name));
        if (validForm) {
            /*
            * Encodage du fichier sélectionné en JSON pour un envoi via une requête AJAX.
            * Les champs du formulaire doivent être ajouté à l'objet formData
            */
            const config = { headers: { 'Content-Type': 'multipart/form-data' } };
            let formData = new FormData();


            formData.append("file", selectedFile);
            const item = {
                category: category,
                name: {
                    fr: nameFr,
                    en: nameEn,
                },
                description: {
                    fr: descriptionFr,
                    en: descriptionEn,
                }
            };
            formData.append("item", JSON.stringify(item));
            //Requête AJAX vers L'API
            axios.post("http://localhost:4000/portfolio", formData, config)
                .then((response) => {
                    //console.log(response.data);
                    //console.log(response.status);
                    /*
                    * On enregistre le message de confimation de création du projet/certification
                    * afin de l'afficher dans le tableau de bord.
                    */
                    console.log(response.data.message);
                    //sessionStorage.setItem("pwdInitialized", response.data.pwdInitialized);
                    sessionStorage.setItem("itemAdded", response.data.message);
                    navigate("/admin/dashboard");
                }).catch((err) => {

                    if (err.response) {
                        //console.log(err.response.status);
                        //console.log(err.response.data);
                        setErrorForm(err.response.data.message);
                        setErrorFormDisplay("block");
                    }
                });
        }
    }

    return (
        <div className="containerApp">
            <SectionTitle title="Ajout d'un nouvel item" />
            <Form id="newItemForm">
                <Form.Field>
                    <Label pointing='below'>Catégorie</Label>
                    <Select placeholder='Catégorie' options={categories} name="category"
                        value={category} onChange={(event, { value }) => setCategory(value)}
                        onFocus={() => setErrorCategoryDisplay("none")} />
                    <Label pointing prompt style={{ display: errorCategoryDisplay }}>
                        {errorCategory}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Nom</Label>
                    <Input placeholder='Nom' value={nameFr}
                        onChange={(event) => setNameFr(event.target.value)}
                        onFocus={() => setErrorNameFrDisplay("none")} />
                    <Label pointing prompt style={{ display: errorNameFrDisplay }}>
                        {errorNameFr}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Name</Label>
                    <Input placeholder='Name (english)' value={nameEn}
                        onChange={(event) => setNameEn(event.target.value)}
                        onFocus={() => setErrorNameEnDisplay("none")} />
                    <Label pointing prompt style={{ display: errorNameEnDisplay }}>
                        {errorNameEn}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Description</Label>
                    <TextArea placeholder='Description' value={descriptionFr}
                        onChange={(event) => setDescriptionFr(event.target.value)}
                        onFocus={() => setErrorDescriptionFrDisplay("none")} />
                    <Label pointing prompt style={{ display: errorDescriptionFrDisplay }}>
                        {errorDescriptionFr}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>Description</Label>
                    <TextArea placeholder='Description (english)' value={descriptionEn}
                        onChange={(event) => setDescriptionEn(event.target.value)}
                        onFocus={() => setErrorDescriptionEnDisplay("none")} />
                    <Label pointing prompt style={{ display: errorDescriptionEnDisplay }}>
                        {errorDescriptionEn}
                    </Label>
                </Form.Field>
                <Form.Field>
                    <Label pointing='below'>
                        Charger un fichier image depuis votre ordinateur<br />
                        Types acceptés : uniquement .png, .jpg et .jpeg
                    </Label>
                    <Input type="file" icon labelPosition='left'
                        onChange={handleFileSelection}
                        onFocus={() => setErrorImageDisplay("none")} />
                    <Label pointing prompt style={{ display: errorImageDisplay }}>
                        {errorImage}
                    </Label>
                </Form.Field>
                <Button primary icon labelPosition='left' type='submit' onClick={handleSubmit}>
                    <Icon name="save" />
                    Valider
                </Button>
                <Button icon labelPosition='left'
                    onClick={() => navigate('/admin/dashboard')} id="cancel">
                    <Icon name='cancel' />Annuler
                </Button>
                <Form.Field>
                    <Label id="errorForm" pointing prompt style={{ display: errorFormDisplay }}>
                        {errorForm}
                    </Label>
                </Form.Field>
            </Form>
        </div>
    );
}
export default ItemAdd;