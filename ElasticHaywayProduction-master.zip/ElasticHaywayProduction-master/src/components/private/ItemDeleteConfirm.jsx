import React from "react";
import "../../styles/App.css"
import { useNavigate } from "react-router-dom";
import { Form, Icon, Button, Label } from "semantic-ui-react";
import axios from "axios";
import SectionTitle from "../SectionTitle";
/*
* Cette fontion nettoie la session des données inutiles avant de retourner 
* à la page de la liste des publications/articles
*/
function cleanSession() {
    sessionStorage.removeItem("itemId");
    sessionStorage.removeItem("itemName");
}


function ItemDeleteConfirm() {
    const itemName = sessionStorage.getItem("itemName");
    const navigate = useNavigate();
    const handleSubmit = (event) => {
        event.preventDefault();
        const itemId = sessionStorage.getItem("itemId");

        axios.delete(`http://localhost:4000/portfolio/${itemId}`)
            .then((response) => {
                console.log(response.data);
                console.log(response.status);
                cleanSession();
                sessionStorage.setItem("itemDeleted", response.data.message);
                navigate("/admin/dashboard");
            }).catch((err) => {
                if (err.response) {
                    console.log(err.response.status);
                    console.log(err.response.data);
                }
            });
    }
    return (
        <div className="containerApp">
            <SectionTitle title="Suppression d'un item" />
            <Form>
                <Form.Field>
                    <Label>Vous êtes sûr de vouloir supprimer l'item intitulé <b>{itemName}</b>?</Label>
                    <Button icon labelPosition='left'
                        onClick={() => {
                            navigate('/admin/dashboard');
                            cleanSession();
                        }
                        } id="cancel">
                        <Icon name='arrow left' />Annuler
                    </Button>
                    <Button icon labelPosition='left' type='submit' negative
                        onClick={handleSubmit}>
                        <Icon name='trash alternate' />Confirmer la suppression
                    </Button>
                </Form.Field >
            </Form >
        </div >
    );
}
export default ItemDeleteConfirm;