import React, { useState } from "react";
import "../../styles/App.css"
import { useNavigate } from 'react-router-dom';
import { Label, Form, Button, Icon } from "semantic-ui-react";
import axios from "axios";
import SectionTitle from "../SectionTitle";

function PasswordEdit() {

  /*
  * State pour les différents messages d'erreur
  */
  const [errorCurrentPwd, setErrorCurrentPwd] = useState("");
  const [errorNewPwd, setErrorNewPwd] = useState("");
  const [errorNewPwdConfirm, setErrorNewPwdConfirm] = useState("");
  const [errorForm, setErrorForm] = useState("");

  /*
  * State pour afficher/masquer un des <Label> d'erreur : initialement, chaque composant
  * est masqué (display : none). À chaque fois qu'un composant doit être affiché, on 
  * met à jour son état avec le style display : block
  */
  const [errorCurrentPwdDisplay, setErrorCurrentPwdDisplay] = useState("none");
  const [errorNewPwdDisplay, setErrorNewPwdDisplay] = useState("none");
  const [errorNewPwdConfirmDisplay, setErrorNewPwdConfirmDisplay] = useState("none");
  const [errorFormDisplay, setErrorFormDisplay] = useState("none");


  const navigate = useNavigate();
  const [currentPwd, setCurrentPwd] = useState("");
  /*
  * On vérifie si le mot de passe courant n'a pas été sauvagardé dans la 
  * session courante. Cela survient en cas de première connexion de l'admin : 
  * celui-ci doit changer son mot passe (mot de passe fourni par défaut).
  */
  if (sessionStorage.getItem("currentPwd")) {
    setCurrentPwd(sessionStorage.getItem("currentPwd"))
  }
  const [newPwd, setNewPwd] = useState("");
  const [newPwdConfirm, setNewPwdConfirm] = useState("");
  //const [error, setError] = useState("");

  const handleSubmit = (event) => {
    //Nettoyage et initialisation
    setCurrentPwd(currentPwd.trim());
    setNewPwd(newPwd.trim());
    setNewPwdConfirm(newPwdConfirm.trim());
    setErrorForm("");
    setErrorFormDisplay("none");
    event.preventDefault();

    //Gestion des messages à afficher en cas d'erreur
    if (currentPwd === "") {
      setErrorCurrentPwd("Le mot de passe actuel est obligatoire");
    }

    if (newPwd.length < 8) {
      setErrorNewPwd("Le nouveau mot de passe doit être avoir une longueur minimale" +
        " de 8 caractères");
    }

    if (newPwdConfirm.length < 8) {
      setErrorNewPwdConfirm("Le confirmation du  mot de passe doit être avoir une longueur" +
        " minimale de 8 caractères");
    }
    //Gestion de l'affichage des composants
    currentPwd === "" ? setErrorCurrentPwdDisplay("block")
      : setErrorCurrentPwdDisplay("none");
    newPwd.length < 8 ? setErrorNewPwdDisplay("block")
      : setErrorNewPwdDisplay("none");
    newPwdConfirm.length < 8 ? setErrorNewPwdConfirmDisplay("block")
      : setErrorNewPwdConfirmDisplay("none");

    if (newPwd !== newPwdConfirm) {
      setErrorForm("Le mot de passe et sa confirmation ne sont pas identiques");
      setErrorFormDisplay("block");
    } else if (currentPwd === newPwd && newPwd.length >= 8) {
      setErrorForm("Vous devez choisir un mot de passe différent du mot de passe actuel");
      setErrorFormDisplay("block");
    }
    const validForm = currentPwd !== "" && newPwd.length >= 8 && newPwdConfirm.length >= 8
      && newPwd === newPwdConfirm && newPwd !== currentPwd;
    if (validForm) {
      const data = {
        currentPwd: currentPwd,
        newPwd: newPwd
      };
      axios.put("http://localhost:4000/password/edit", data)
        .then((response) => {
          //console.log(response.data);
          //console.log(response.status);
          //On Sauvegarde le message de confirmation dans la session
          sessionStorage.setItem("confirmationUpdatePwd", response.data.message);
          /*
          * On met à jour le mot de passe si l'utilisateur a activé l'option 
          * Rester connecté
          */
          const stayConnected = localStorage.getItem("stayConnected") === "true";
          if (stayConnected) {
            localStorage.setItem("password", newPwd);
          }

          sessionStorage.setItem("pwdInitialized", response.data.pwdInitialized);
          navigate("/admin/dashboard");
        }).catch((err) => {
          if (err.response) {
            console.log(err.response.status);
            console.log(err.response.data);
            setErrorForm(err.response.data.message);
            setErrorFormDisplay("block");
          }
        });
    }
  }
  return (
    <div className="containerApp">
      <SectionTitle title="Modification du mot de passe" />
      <Form>
        <Form.Field>
          <Label pointing='below'>Mot de passe actuel</Label>
          <input type='password' placeholder='Votre mot de passe actuel' value={currentPwd}
            onFocus={() => setErrorCurrentPwdDisplay("none")}
            onChange={(event) => setCurrentPwd(event.target.value)} id="password" />
          <Label pointing prompt style={{ display: errorCurrentPwdDisplay }}>
            {errorCurrentPwd}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Nouveau mot de passe (minimum 8 caractères)</Label>
          <input type='password' placeholder='Votre nouveau mot de passe' value={newPwd}
            onFocus={() => setErrorNewPwdDisplay("none")}
            onChange={(event) => setNewPwd(event.target.value)} id="password" />
          <Label pointing prompt style={{ display: errorNewPwdDisplay }}>
            {errorNewPwd}
          </Label>
        </Form.Field>
        <Form.Field>
          <Label pointing='below'>Confirmation du mot de passe (minimum 8 caractères)</Label>
          <input type='password' placeholder='Confirmation du nouveau mot de passe' value={newPwdConfirm}
            onFocus={() => setErrorNewPwdConfirmDisplay("none")}
            onChange={(event) => setNewPwdConfirm(event.target.value)} id="password" />
          <Label pointing prompt style={{ display: errorNewPwdConfirmDisplay }}>
            {errorNewPwdConfirm}
          </Label>
        </Form.Field>
        <Button primary icon labelPosition='left' type='submit' onClick={handleSubmit}>
          <Icon name='edit' />
          Modifier
        </Button>
        <Button icon labelPosition='left'
          onClick={() => navigate('/admin/dashboard')} id="cancel">
          <Icon name='cancel' />Annuler
        </Button>
        <Form.Field>
          <Label id="errorForm" pointing prompt style={{ display: errorFormDisplay }}>
            {errorForm}
          </Label>
        </Form.Field>
      </Form>
    </div>
  );
}
export default PasswordEdit;