import React, {createContext, useState} from "react";

const Context = createContext();
const supportedLangs = ["fr", "en"];
let currentLang = "en";

if(supportedLangs.indexOf(navigator.language.split("-")[0]) !== -1){
    currentLang = navigator.language.split("-")[0];
}

const ContextProvider = (props)=>{
    const[lang, setLang] = useState(currentLang);
    const toggleLang = (newLang)=>{
        setLang(newLang);
    }
    return(
        <Context.Provider value={{lang, toggleLang}}>
            {props.children}
        </Context.Provider>
    );
}

export {Context};
export default ContextProvider;