import './styles/App.css';
import React, { useEffect } from "react";
import { Routes, Route } from "react-router-dom";

import Login from './components/private/Login';
import Dashboard from './components/private/Dashboard';
import Error from './components/Error';
import axios from "axios";
import ItemAdd from './components/private/ItemAdd';
import ItemEdit from './components/private/ItemEdit';
import ItemDeleteConfirm from './components/private/ItemDeleteConfirm';
import ItemDetails from './components/private/ItemDetails';
import PasswordEdit from './components/private/PasswordEdit';
import PublicationDashboard from './components/private/PublicationDashboard';
import PublicationAdd from './components/private/PublicationAdd';
import PublicationEdit from './components/private/PublicationEdit';
import PublicationDeleteConfirm from './components/private/PublicationDeleteConfirm';
import PasswordReset from './components/private/PasswordReset';
import NotFound from './components/NotFound';
import ContextContent from './components/ContextContent';

export const AUT_TOKEN_KEY = "jwt-authentification-token";
function App() {
  
  /*
  * Intercepteurs pour injecter le jeton d'authentification à toutes 
  * les requêtes (si ce jeton existe dans la session)
  */
  useEffect(() => {
    axios.interceptors.request.use((request) => {
      /*
      * On vérifie si le jeton existe dans la session courant. 
      * Si c'est le cas, on le rajoute au header de la requête
      * courante avant d'envoyer celle-ci au serveur.
      */
      const token = sessionStorage.getItem(AUT_TOKEN_KEY);
      if (token) {
        request.headers.Authorization = `Bearer ${token}`;
      }
      return request;
    }, (error) => {
      return Promise.reject(error);
    });
  }, []);

  return (
    <Routes>
      <Route path="/" exact element={
        <ContextContent />
      } />
      <Route path="/admin/dashboard/itemAdd" element={<ItemAdd />} />
      <Route path="/admin/dashboard/itemEdit" element={<ItemEdit />} />
      <Route path="/admin/dashboard/itemDelete" element={<ItemDeleteConfirm />} />
      <Route path="/admin/dashboard/itemDetails" element={<ItemDetails />} />
      <Route exact path="/admin/dashboard/passEdit" element={<PasswordEdit />} />
      <Route path="/admin/dashboard/publication" element={<PublicationDashboard />} />
      <Route path="/admin/dashboard/publication/add" element={<PublicationAdd />} />
      <Route path="/admin/dashboard/publication/edit" element={<PublicationEdit />} />
      <Route path="/admin/dashboard/publication/delete" element={<PublicationDeleteConfirm />} />
      <Route exact path="/admin/dashboard" element={<Dashboard />} />
      <Route path="/admin/passInit" element={<PasswordReset />} />
      <Route exact path="/admin" element={<Login />} />
      <Route path="/error" element={<Error />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
